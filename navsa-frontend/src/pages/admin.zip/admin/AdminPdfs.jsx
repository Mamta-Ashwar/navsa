// import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
// import {
//   deletePdf,
//   getPdfs,
//   updatePdf,
//   uploadPdf,
// } from '../../services/adminApi'
// import {
//   Eye,
//   FileText,
//   Pencil,
//   Plus,
//   Save,
//   Trash2,
//   Upload,
//   X,
// } from 'lucide-react'

// const EMPTY_FORM = {
//   title: '',
//   type: 'deal',
//   badge: '',
//   valid_from: '',
//   valid_to: '',
//   validity_text: '',
//   description: '',
//   sort_order: 1,
//   is_active: true,
//   file: null,
// }

// const TABS = [
//   { key: 'deal', label: 'Deals & Promotion PDFs' },
//   { key: 'manual', label: 'Product Manuals' },
//   { key: 'other', label: 'Other Documents' },
// ]

// function fileUrl(pdf) {
//   if (pdf.file_url) return pdf.file_url

//   const apiBase = import.meta.env.VITE_API_URL || ''
//   const siteBase = apiBase.endsWith('/api') ? apiBase.slice(0, -4) : apiBase
//   return `${siteBase || ''}/storage/${pdf.file_path}`
// }

// function formatDate(value) {
//   if (!value) return ''
//   const date = new Date(`${value}T00:00:00`)
//   if (Number.isNaN(date.getTime())) return value
//   return new Intl.DateTimeFormat('en-GB').format(date)
// }

// function PdfForm({ initial, activeDealCount, onCancel, onSaved }) {
//   const [form, setForm] = useState(initial || EMPTY_FORM)
//   const [busy, setBusy] = useState(false)
//   const fileInputRef = useRef(null)
//   const editing = Boolean(initial?.id)

//   const set = (key, value) => {
//     setForm((current) => ({ ...current, [key]: value }))
//   }

//   const submit = async (event) => {
//     event.preventDefault()

//     if (!form.title.trim()) {
//       alert('Please enter the title.')
//       return
//     }

//     if (!editing && !form.file) {
//       alert('Please choose a PDF file.')
//       return
//     }

//     if (form.valid_from && form.valid_to && form.valid_to < form.valid_from) {
//       alert('Valid To cannot be earlier than Valid From.')
//       return
//     }

//     if (
//       form.type === 'deal'
//       && form.is_active
//       && !initial?.is_active
//       && activeDealCount >= 4
//     ) {
//       alert('Only four deal PDFs can be active at the same time.')
//       return
//     }

//     setBusy(true)

//     try {
//       const payload = {
//         title: form.title.trim(),
//         type: form.type,
//         badge: form.badge.trim(),
//         valid_from: form.valid_from,
//         valid_to: form.valid_to,
//         validity_text: form.validity_text.trim(),
//         description: form.description.trim(),
//         sort_order: Number(form.sort_order) || 1,
//         is_active: Boolean(form.is_active),
//         file: form.file,
//       }

//       if (editing) {
//         await updatePdf(initial.id, payload)
//       } else {
//         await uploadPdf(payload)
//       }

//       onSaved()
//     } catch (error) {
//       alert(error.message)
//     } finally {
//       setBusy(false)
//     }
//   }

//   return (
//     <form onSubmit={submit} className="glass-panel" style={{ padding: '24px', marginBottom: '22px' }}>
//       <div className="admin-flex-between" style={{ marginBottom: '18px' }}>
//         <div>
//           <h3 style={{ margin: 0 }}>{editing ? 'Edit PDF' : 'Add PDF'}</h3>
//           <p style={{ color: '#94a3b8', margin: '5px 0 0' }}>
//             {form.type === 'deal'
//               ? 'The active deal content appears automatically on the public website.'
//               : 'Upload and manage downloadable documents.'}
//           </p>
//         </div>

//         <button type="button" onClick={onCancel} className="admin-btn admin-btn-ghost">
//           <X size={17} /> Close
//         </button>
//       </div>

//       <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '14px' }}>
//         <label>
//           <span className="admin-form-label">Document type</span>
//           <select
//             className="admin-input-field"
//             value={form.type}
//             onChange={(event) => set('type', event.target.value)}
//             style={{ width: '100%' }}
//           >
//             <option value="deal">Deal / Promotion PDF</option>
//             <option value="manual">Product Manual</option>
//             <option value="other">Other Document</option>
//           </select>
//         </label>

//         <label>
//           <span className="admin-form-label">Title</span>
//           <input
//             className="admin-input-field"
//             value={form.title}
//             onChange={(event) => set('title', event.target.value)}
//             placeholder="NAVSA P10"
//             maxLength={255}
//             style={{ width: '100%' }}
//           />
//         </label>

//         {form.type === 'deal' && (
//           <>
//             <label>
//               <span className="admin-form-label">Badge</span>
//               <input
//                 className="admin-input-field"
//                 value={form.badge}
//                 onChange={(event) => set('badge', event.target.value)}
//                 placeholder="LATEST, NEW, CHRISTMAS"
//                 maxLength={50}
//                 style={{ width: '100%' }}
//               />
//             </label>

//             <label>
//               <span className="admin-form-label">Display order</span>
//               <input
//                 type="number"
//                 min="1"
//                 max="999"
//                 className="admin-input-field"
//                 value={form.sort_order}
//                 onChange={(event) => set('sort_order', event.target.value)}
//                 style={{ width: '100%' }}
//               />
//             </label>

//             <label>
//               <span className="admin-form-label">Valid from</span>
//               <input
//                 type="date"
//                 className="admin-input-field"
//                 value={form.valid_from || ''}
//                 onChange={(event) => set('valid_from', event.target.value)}
//                 style={{ width: '100%' }}
//               />
//             </label>

//             <label>
//               <span className="admin-form-label">Valid to</span>
//               <input
//                 type="date"
//                 className="admin-input-field"
//                 value={form.valid_to || ''}
//                 onChange={(event) => set('valid_to', event.target.value)}
//                 style={{ width: '100%' }}
//               />
//             </label>

//             <label style={{ gridColumn: '1 / -1' }}>
//               <span className="admin-form-label">Validity text override</span>
//               <input
//                 className="admin-input-field"
//                 value={form.validity_text || ''}
//                 onChange={(event) => set('validity_text', event.target.value)}
//                 placeholder="Seasonal Specials — leave blank to show the dates"
//                 maxLength={255}
//                 style={{ width: '100%' }}
//               />
//             </label>

//             <label style={{ gridColumn: '1 / -1' }}>
//               <span className="admin-form-label">Frontend description</span>
//               <textarea
//                 className="admin-input-field"
//                 value={form.description || ''}
//                 onChange={(event) => set('description', event.target.value)}
//                 placeholder="Monthly impulse promotions with all the top UK brands..."
//                 maxLength={2000}
//                 rows={4}
//                 style={{ width: '100%', resize: 'vertical' }}
//               />
//             </label>
//           </>
//         )}

//         <label style={{ gridColumn: '1 / -1' }}>
//           <span className="admin-form-label">
//             {editing ? 'Replace PDF (optional)' : 'PDF file'}
//           </span>
//           <input
//             ref={fileInputRef}
//             type="file"
//             accept="application/pdf,.pdf"
//             className="admin-input-field"
//             onChange={(event) => set('file', event.target.files?.[0] || null)}
//             style={{ width: '100%' }}
//           />
//         </label>

//         {form.type === 'deal' && (
//           <label style={{ display: 'flex', alignItems: 'center', gap: '10px', gridColumn: '1 / -1' }}>
//             <input
//               type="checkbox"
//               checked={Boolean(form.is_active)}
//               onChange={(event) => set('is_active', event.target.checked)}
//             />
//             <span>Show this deal on the public website</span>
//           </label>
//         )}
//       </div>

//       <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
//         <button type="submit" disabled={busy} className="admin-btn admin-btn-primary">
//           {editing ? <Save size={17} /> : <Upload size={17} />}
//           {busy ? 'Saving...' : editing ? 'Save Changes' : 'Upload PDF'}
//         </button>

//         <button type="button" onClick={onCancel} className="admin-btn admin-btn-ghost">
//           Cancel
//         </button>
//       </div>
//     </form>
//   )
// }

// export default function AdminPdfs() {
//   const [pdfs, setPdfs] = useState([])
//   const [loading, setLoading] = useState(true)
//   const [tab, setTab] = useState('deal')
//   const [editing, setEditing] = useState(null)
//   const [showForm, setShowForm] = useState(false)

//   const load = useCallback(async () => {
//     setLoading(true)

//     try {
//       setPdfs(await getPdfs())
//     } catch (error) {
//       alert(error.message)
//     } finally {
//       setLoading(false)
//     }
//   }, [])

//   useEffect(() => {
//     load()
//   }, [load])

//   const displayed = useMemo(
//     () => pdfs.filter((pdf) => pdf.type === tab),
//     [pdfs, tab],
//   )

//   const activeDealCount = useMemo(
//     () => pdfs.filter((pdf) => pdf.type === 'deal' && pdf.is_active).length,
//     [pdfs],
//   )

//   const openCreate = () => {
//     setEditing(null)
//     setShowForm(true)
//   }

//   const openEdit = (pdf) => {
//     setEditing({
//       ...pdf,
//       valid_from: pdf.valid_from || '',
//       valid_to: pdf.valid_to || '',
//       file: null,
//     })
//     setShowForm(true)
//   }

//   const closeForm = () => {
//     setEditing(null)
//     setShowForm(false)
//   }

//   const saved = async () => {
//     closeForm()
//     await load()
//   }

//   const remove = async (pdf) => {
//     if (!confirm(`Delete “${pdf.title}”? This also deletes the uploaded PDF file.`)) {
//       return
//     }

//     try {
//       await deletePdf(pdf.id)
//       await load()
//     } catch (error) {
//       alert(error.message)
//     }
//   }

//   return (
//     <div>
//       <div className="admin-flex-between mb-6">
//         <div>
//           <h1 style={{ marginBottom: '0.25rem' }}>PDFs & Manuals</h1>
//           <p style={{ color: '#94a3b8' }}>
//             Manage deal brochures and downloadable documents without changing website code.
//           </p>
//         </div>

//         <button onClick={openCreate} className="admin-btn admin-btn-primary">
//           <Plus size={18} /> Add PDF
//         </button>
//       </div>

//       <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', flexWrap: 'wrap' }}>
//         {TABS.map((item) => (
//           <button
//             key={item.key}
//             type="button"
//             onClick={() => {
//               setTab(item.key)
//               closeForm()
//             }}
//             className={`admin-btn ${tab === item.key ? 'admin-btn-primary' : 'admin-btn-ghost'}`}
//           >
//             {item.label}
//           </button>
//         ))}
//       </div>

//       {showForm && (
//         <PdfForm
//           key={editing?.id || `new-${tab}`}
//           initial={editing || { ...EMPTY_FORM, type: tab }}
//           activeDealCount={activeDealCount}
//           onCancel={closeForm}
//           onSaved={saved}
//         />
//       )}

//       {tab === 'deal' && (
//         <div className="glass-panel" style={{ padding: '16px', marginBottom: '20px', border: '1px solid rgba(59,130,246,0.35)' }}>
//           <strong>Public website deals: {activeDealCount}/4 active</strong>
//           <p style={{ color: '#94a3b8', margin: '6px 0 0' }}>
//             Only active Deal / Promotion PDFs appear on the frontend. Display Order controls their sequence.
//           </p>
//         </div>
//       )}

//       <div className="glass-panel" style={{ padding: '1.5rem' }}>
//         {loading ? (
//           <div style={{ color: '#94a3b8', padding: '40px', textAlign: 'center' }}>
//             Loading PDFs…
//           </div>
//         ) : displayed.length === 0 ? (
//           <div style={{ color: '#94a3b8', padding: '40px', textAlign: 'center' }}>
//             No documents found in this section.
//           </div>
//         ) : (
//           <div className="admin-table-container">
//             <table className="admin-table">
//               <thead>
//                 <tr>
//                   <th>Title</th>
//                   {tab === 'deal' && <th>Badge</th>}
//                   {tab === 'deal' && <th>Validity</th>}
//                   {tab === 'deal' && <th>Order</th>}
//                   {tab === 'deal' && <th>Website</th>}
//                   <th>PDF</th>
//                   <th>Actions</th>
//                 </tr>
//               </thead>

//               <tbody>
//                 {displayed.map((pdf) => {
//                   const validity = pdf.validity_text
//                     || (pdf.valid_from && pdf.valid_to
//                       ? `${formatDate(pdf.valid_from)} to ${formatDate(pdf.valid_to)}`
//                       : '—')

//                   return (
//                     <tr key={pdf.id}>
//                       <td>
//                         <div style={{ fontWeight: 700 }}>{pdf.title}</div>
//                         {pdf.description && (
//                           <div style={{ color: '#94a3b8', fontSize: '12px', marginTop: '4px', maxWidth: '420px' }}>
//                             {pdf.description}
//                           </div>
//                         )}
//                       </td>

//                       {tab === 'deal' && <td>{pdf.badge || 'PROMOTION'}</td>}
//                       {tab === 'deal' && <td>{validity}</td>}
//                       {tab === 'deal' && <td>{pdf.sort_order}</td>}
//                       {tab === 'deal' && (
//                         <td>
//                           <span className={`admin-badge ${pdf.is_active ? 'admin-badge-success' : 'admin-badge-danger'}`}>
//                             {pdf.is_active ? 'Visible' : 'Hidden'}
//                           </span>
//                         </td>
//                       )}

//                       <td>
//                         <a
//                           href={fileUrl(pdf)}
//                           target="_blank"
//                           rel="noreferrer"
//                           style={{ color: '#60a5fa', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
//                         >
//                           <Eye size={16} /> View
//                         </a>
//                       </td>

//                       <td>
//                         <div style={{ display: 'flex', gap: '6px' }}>
//                           <button
//                             type="button"
//                             onClick={() => openEdit(pdf)}
//                             className="admin-btn admin-btn-ghost"
//                             title="Edit"
//                           >
//                             <Pencil size={16} />
//                           </button>

//                           <button
//                             type="button"
//                             onClick={() => remove(pdf)}
//                             className="admin-btn admin-btn-ghost"
//                             style={{ color: '#ef4444' }}
//                             title="Delete"
//                           >
//                             <Trash2 size={16} />
//                           </button>
//                         </div>
//                       </td>
//                     </tr>
//                   )
//                 })}
//               </tbody>
//             </table>
//           </div>
//         )}
//       </div>
//     </div>
//   )
// }

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  deletePdf,
  getPdfs,
  updatePdf,
  uploadPdf,
} from '../../services/adminApi'
import {
  Eye,
  FileText,
  Pencil,
  Plus,
  Save,
  Trash2,
  Upload,
  X,
} from 'lucide-react'

const EMPTY_FORM = {
  title: '',
  type: 'deal',
  badge: '',
  valid_from: '',
  valid_to: '',
  validity_text: '',
  description: '',
  sort_order: 1,
  is_active: true,
  file: null,
}

const TABS = [
  { key: 'deal', label: 'Deals & Promotion PDFs' },
  { key: 'manual', label: 'Product Manuals' },
  { key: 'other', label: 'Other Documents' },
]

function fileUrl(pdf) {
  if (pdf.file_url) return pdf.file_url

  const apiBase = import.meta.env.VITE_API_URL || ''
  const siteBase = apiBase.endsWith('/api') ? apiBase.slice(0, -4) : apiBase
  return `${siteBase || ''}/storage/${pdf.file_path}`
}

function formatDate(value) {
  if (!value) return ''
  const date = new Date(`${value}T00:00:00`)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat('en-GB').format(date)
}

function PdfForm({ initial, activeDealCount, onCancel, onSaved }) {
  const [form, setForm] = useState(initial || EMPTY_FORM)
  const [busy, setBusy] = useState(false)
  const fileInputRef = useRef(null)
  const editing = Boolean(initial?.id)

  const set = (key, value) => {
    setForm((current) => ({ ...current, [key]: value }))
  }

  const submit = async (event) => {
    event.preventDefault()

    if (!form.title.trim()) {
      alert('Please enter the title.')
      return
    }

    if (!editing && !form.file) {
      alert('Please choose a PDF file.')
      return
    }

    if (form.valid_from && form.valid_to && form.valid_to < form.valid_from) {
      alert('Valid To cannot be earlier than Valid From.')
      return
    }

    if (
      form.type === 'deal'
      && form.is_active
      && !initial?.is_active
      && activeDealCount >= 4
    ) {
      alert('Only four deal PDFs can be active at the same time.')
      return
    }

    setBusy(true)

    try {
      const payload = new FormData()
      payload.append('title', form.title.trim())
      payload.append('type', form.type)
      payload.append('badge', form.badge.trim())
      payload.append('valid_from', form.valid_from || '')
      payload.append('valid_to', form.valid_to || '')
      payload.append('validity_text', form.validity_text.trim())
      payload.append('description', form.description.trim())
      payload.append('sort_order', String(Number(form.sort_order) || 1))
      payload.append('is_active', form.is_active ? '1' : '0')
      if (form.file) payload.append('file', form.file)

      if (editing) {
        await updatePdf(initial.id, payload)
      } else {
        await uploadPdf(payload)
      }

      onSaved()
    } catch (error) {
      alert(error.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit} className="glass-panel" style={{ padding: '24px', marginBottom: '22px' }}>
      <div className="admin-flex-between" style={{ marginBottom: '18px' }}>
        <div>
          <h3 style={{ margin: 0 }}>{editing ? 'Edit PDF' : 'Add PDF'}</h3>
          <p style={{ color: '#94a3b8', margin: '5px 0 0' }}>
            {form.type === 'deal'
              ? 'The active deal content appears automatically on the public website.'
              : 'Upload and manage downloadable documents.'}
          </p>
        </div>

        <button type="button" onClick={onCancel} className="admin-btn admin-btn-ghost">
          <X size={17} /> Close
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '14px' }}>
        <label>
          <span className="admin-form-label">Document type</span>
          <select
            className="admin-input-field"
            value={form.type}
            onChange={(event) => set('type', event.target.value)}
            style={{ width: '100%' }}
          >
            <option value="deal">Deal / Promotion PDF</option>
            <option value="manual">Product Manual</option>
            <option value="other">Other Document</option>
          </select>
        </label>

        <label>
          <span className="admin-form-label">Title</span>
          <input
            className="admin-input-field"
            value={form.title}
            onChange={(event) => set('title', event.target.value)}
            placeholder="NAVSA P10"
            maxLength={255}
            style={{ width: '100%' }}
          />
        </label>

        {form.type === 'deal' && (
          <>
            <label>
              <span className="admin-form-label">Badge</span>
              <input
                className="admin-input-field"
                value={form.badge}
                onChange={(event) => set('badge', event.target.value)}
                placeholder="LATEST, NEW, CHRISTMAS"
                maxLength={50}
                style={{ width: '100%' }}
              />
            </label>

            <label>
              <span className="admin-form-label">Display order</span>
              <input
                type="number"
                min="1"
                max="999"
                className="admin-input-field"
                value={form.sort_order}
                onChange={(event) => set('sort_order', event.target.value)}
                style={{ width: '100%' }}
              />
            </label>

            <label>
              <span className="admin-form-label">Valid from</span>
              <input
                type="date"
                className="admin-input-field"
                value={form.valid_from || ''}
                onChange={(event) => set('valid_from', event.target.value)}
                style={{ width: '100%' }}
              />
            </label>

            <label>
              <span className="admin-form-label">Valid to</span>
              <input
                type="date"
                className="admin-input-field"
                value={form.valid_to || ''}
                onChange={(event) => set('valid_to', event.target.value)}
                style={{ width: '100%' }}
              />
            </label>

            <label style={{ gridColumn: '1 / -1' }}>
              <span className="admin-form-label">Validity text override</span>
              <input
                className="admin-input-field"
                value={form.validity_text || ''}
                onChange={(event) => set('validity_text', event.target.value)}
                placeholder="Seasonal Specials — leave blank to show the dates"
                maxLength={255}
                style={{ width: '100%' }}
              />
            </label>

            <label style={{ gridColumn: '1 / -1' }}>
              <span className="admin-form-label">Frontend description</span>
              <textarea
                className="admin-input-field"
                value={form.description || ''}
                onChange={(event) => set('description', event.target.value)}
                placeholder="Monthly impulse promotions with all the top UK brands..."
                maxLength={2000}
                rows={4}
                style={{ width: '100%', resize: 'vertical' }}
              />
            </label>
          </>
        )}

        <label style={{ gridColumn: '1 / -1' }}>
          <span className="admin-form-label">
            {editing ? 'Replace PDF (optional)' : 'PDF file'}
          </span>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf,.pdf"
            className="admin-input-field"
            onChange={(event) => set('file', event.target.files?.[0] || null)}
            style={{ width: '100%' }}
          />
        </label>

        {form.type === 'deal' && (
          <label style={{ display: 'flex', alignItems: 'center', gap: '10px', gridColumn: '1 / -1' }}>
            <input
              type="checkbox"
              checked={Boolean(form.is_active)}
              onChange={(event) => set('is_active', event.target.checked)}
            />
            <span>Show this deal on the public website</span>
          </label>
        )}
      </div>

      <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
        <button type="submit" disabled={busy} className="admin-btn admin-btn-primary">
          {editing ? <Save size={17} /> : <Upload size={17} />}
          {busy ? 'Saving...' : editing ? 'Save Changes' : 'Upload PDF'}
        </button>

        <button type="button" onClick={onCancel} className="admin-btn admin-btn-ghost">
          Cancel
        </button>
      </div>
    </form>
  )
}

export default function AdminPdfs() {
  const [pdfs, setPdfs] = useState([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('deal')
  const [editing, setEditing] = useState(null)
  const [showForm, setShowForm] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)

    try {
      setPdfs(await getPdfs())
    } catch (error) {
      alert(error.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const displayed = useMemo(
    () => pdfs.filter((pdf) => pdf.type === tab),
    [pdfs, tab],
  )

  const activeDealCount = useMemo(
    () => pdfs.filter((pdf) => pdf.type === 'deal' && pdf.is_active).length,
    [pdfs],
  )

  const openCreate = () => {
    setEditing(null)
    setShowForm(true)
  }

  const openEdit = (pdf) => {
    setEditing({
      ...pdf,
      valid_from: pdf.valid_from || '',
      valid_to: pdf.valid_to || '',
      file: null,
    })
    setShowForm(true)
  }

  const closeForm = () => {
    setEditing(null)
    setShowForm(false)
  }

  const saved = async () => {
    closeForm()
    await load()
  }

  const remove = async (pdf) => {
    if (!confirm(`Delete “${pdf.title}”? This also deletes the uploaded PDF file.`)) {
      return
    }

    try {
      await deletePdf(pdf.id)
      await load()
    } catch (error) {
      alert(error.message)
    }
  }

  return (
    <div>
      <div className="admin-flex-between mb-6">
        <div>
          <h1 style={{ marginBottom: '0.25rem' }}>PDFs & Manuals</h1>
          <p style={{ color: '#94a3b8' }}>
            Manage deal brochures and downloadable documents without changing website code.
          </p>
        </div>

        <button onClick={openCreate} className="admin-btn admin-btn-primary">
          <Plus size={18} /> Add PDF
        </button>
      </div>

      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', flexWrap: 'wrap' }}>
        {TABS.map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => {
              setTab(item.key)
              closeForm()
            }}
            className={`admin-btn ${tab === item.key ? 'admin-btn-primary' : 'admin-btn-ghost'}`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {showForm && (
        <PdfForm
          key={editing?.id || `new-${tab}`}
          initial={editing || { ...EMPTY_FORM, type: tab }}
          activeDealCount={activeDealCount}
          onCancel={closeForm}
          onSaved={saved}
        />
      )}

      {tab === 'deal' && (
        <div className="glass-panel" style={{ padding: '16px', marginBottom: '20px', border: '1px solid rgba(59,130,246,0.35)' }}>
          <strong>Public website deals: {activeDealCount}/4 active</strong>
          <p style={{ color: '#94a3b8', margin: '6px 0 0' }}>
            Only active Deal / Promotion PDFs appear on the frontend. Display Order controls their sequence.
          </p>
        </div>
      )}

      <div className="glass-panel" style={{ padding: '1.5rem' }}>
        {loading ? (
          <div style={{ color: '#94a3b8', padding: '40px', textAlign: 'center' }}>
            Loading PDFs…
          </div>
        ) : displayed.length === 0 ? (
          <div style={{ color: '#94a3b8', padding: '40px', textAlign: 'center' }}>
            No documents found in this section.
          </div>
        ) : (
          <div className="admin-table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Title</th>
                  {tab === 'deal' && <th>Badge</th>}
                  {tab === 'deal' && <th>Validity</th>}
                  {tab === 'deal' && <th>Order</th>}
                  {tab === 'deal' && <th>Website</th>}
                  <th>PDF</th>
                  <th>Actions</th>
                </tr>
              </thead>

              <tbody>
                {displayed.map((pdf) => {
                  const validity = pdf.validity_text
                    || (pdf.valid_from && pdf.valid_to
                      ? `${formatDate(pdf.valid_from)} to ${formatDate(pdf.valid_to)}`
                      : '—')

                  return (
                    <tr key={pdf.id}>
                      <td>
                        <div style={{ fontWeight: 700 }}>{pdf.title}</div>
                        {pdf.description && (
                          <div style={{ color: '#94a3b8', fontSize: '12px', marginTop: '4px', maxWidth: '420px' }}>
                            {pdf.description}
                          </div>
                        )}
                      </td>

                      {tab === 'deal' && <td>{pdf.badge || 'PROMOTION'}</td>}
                      {tab === 'deal' && <td>{validity}</td>}
                      {tab === 'deal' && <td>{pdf.sort_order}</td>}
                      {tab === 'deal' && (
                        <td>
                          <span className={`admin-badge ${pdf.is_active ? 'admin-badge-success' : 'admin-badge-danger'}`}>
                            {pdf.is_active ? 'Visible' : 'Hidden'}
                          </span>
                        </td>
                      )}

                      <td>
                        <a
                          href={fileUrl(pdf)}
                          target="_blank"
                          rel="noreferrer"
                          style={{ color: '#60a5fa', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
                        >
                          <Eye size={16} /> View
                        </a>
                      </td>

                      <td>
                        <div style={{ display: 'flex', gap: '6px' }}>
                          <button
                            type="button"
                            onClick={() => openEdit(pdf)}
                            className="admin-btn admin-btn-ghost"
                            title="Edit"
                          >
                            <Pencil size={16} />
                          </button>

                          <button
                            type="button"
                            onClick={() => remove(pdf)}
                            className="admin-btn admin-btn-ghost"
                            style={{ color: '#ef4444' }}
                            title="Delete"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}